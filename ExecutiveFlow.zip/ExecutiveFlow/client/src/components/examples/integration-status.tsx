import { IntegrationStatus } from '../integration-status';

export default function IntegrationStatusExample() {
  return (
    <div className="p-4 max-w-md">
      <IntegrationStatus />
    </div>
  );
}
