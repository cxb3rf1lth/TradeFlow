import { SearchBar } from '../search-bar';

export default function SearchBarExample() {
  return (
    <div className="p-4">
      <SearchBar />
    </div>
  );
}
