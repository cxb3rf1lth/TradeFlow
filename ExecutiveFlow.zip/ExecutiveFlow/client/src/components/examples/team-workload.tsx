import { TeamWorkload } from '../team-workload';

export default function TeamWorkloadExample() {
  return (
    <div className="p-4 max-w-md">
      <TeamWorkload />
    </div>
  );
}
