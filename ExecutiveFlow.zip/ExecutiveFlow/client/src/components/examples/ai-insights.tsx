import { AIInsights } from '../ai-insights';

export default function AIInsightsExample() {
  return (
    <div className="p-4 max-w-md">
      <AIInsights />
    </div>
  );
}
