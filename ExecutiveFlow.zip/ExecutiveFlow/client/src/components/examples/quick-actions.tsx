import { QuickActions } from '../quick-actions';

export default function QuickActionsExample() {
  return (
    <div className="p-4">
      <QuickActions />
    </div>
  );
}
