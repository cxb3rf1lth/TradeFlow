import { ActivityTimeline } from '../activity-timeline';

export default function ActivityTimelineExample() {
  return (
    <div className="p-4 max-w-md">
      <ActivityTimeline />
    </div>
  );
}
